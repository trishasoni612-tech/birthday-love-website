# Happy Birthday Manas 💗

This is a static birthday website. The password is set to 28102005 (28 October 2005).

## Put it on GitHub from a phone
1. Open your GitHub repository.
2. If you are in the empty-file editor, cancel that edit without saving.
3. In the repository, choose Add file → Upload files (or open the repository's upload page).
4. Upload this `index.html` file and commit the change. If GitHub says the file already exists, choose to replace it.
5. Make sure the final file is named exactly `index.html` in the repository root.

## Vercel
Your Vercel project must be connected to this GitHub repository. After committing the file, Vercel should deploy automatically. If it does not, open Vercel → project → Deployments and redeploy.

## Photos
The photo pickers are a browser preview feature; selected photos are not saved to the public site. To show photos permanently, upload image files into the repository and edit the gallery to use their file paths.

## Privacy note
The password gate is for a cute surprise, not secure authentication. The password is visible in the HTML source and can be bypassed by someone who inspects the site.
